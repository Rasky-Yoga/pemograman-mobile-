package com.example.budayabali;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;


public class Mainm extends AppCompatActivity {

    ImageView populer;
    ImageView berita;
    ImageView tempat;
    ImageView keluhan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainm);

        populer = (ImageView) findViewById(R.id.buttonpopuler);
        berita = (ImageView) findViewById(R.id.buttonberita);
        tempat = (ImageView) findViewById(R.id.buttontempat);
        keluhan = (ImageView) findViewById(R.id.buttonkeluhan);

        populer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(Mainm.this, PopulerMenu.class);
                startActivity(intentLoadNewActivity);
            }
        });
        berita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(Mainm.this, BeritaMenu.class);
                startActivity(intentLoadNewActivity);
            }
        });
        tempat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 Intent intentLoadNewActivity = new Intent(Mainm.this, TempatMenu.class);
                startActivity(intentLoadNewActivity);
            }
        });
        keluhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(Mainm.this, KeluhanMenu.class);
                startActivity(intentLoadNewActivity);
            }
        });
    }
}