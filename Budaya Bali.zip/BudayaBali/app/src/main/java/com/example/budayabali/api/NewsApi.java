package com.example.budayabali.api;

public class NewsApi {
    public static String GET_TOP_HEADLINES = "https://newsapi.org/v2/top-headlines?country=id&apiKey=98882af850c64d22b2697716e0eea690";

}