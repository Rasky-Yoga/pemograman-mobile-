package com.example.budayabali.holder;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.budayabali.R;
import com.google.android.material.card.MaterialCardView;

/**
 * Created by Azhar Rivaldi on 22-12-2019.
 */
public class TempatViewHolder extends RecyclerView.ViewHolder {

    public ImageView image;
    public TextView title;
    public TextView publishedAt;
    public MaterialCardView cvNews;
    public View view;
    public Button lokasi;

    public TempatViewHolder(View view) {
        super(view);

        cvNews = view.findViewById(R.id.cvNews);
        image = view.findViewById(R.id.image);
        title = view.findViewById(R.id.title);
        lokasi = view.findViewById(R.id.lokasi);
        publishedAt = view.findViewById(R.id.publishedAt);
        this.view = view;
    }

}