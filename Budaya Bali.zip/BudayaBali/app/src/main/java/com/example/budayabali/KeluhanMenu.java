package com.example.budayabali;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class KeluhanMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keluhan_menu);
    }
}